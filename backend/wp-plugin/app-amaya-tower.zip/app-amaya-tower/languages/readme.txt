Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_amaya-tower-de_DE.po
* app_amaya-tower-id_ID.po
* app_amaya-tower_ES.po
* app_amaya-tower-en_US.po
* app_amaya-tower-de_DE.mo
* app_amaya-tower-id_ID.mo
* app_amaya-tower-es_ES.mo
* app_amaya-tower-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
